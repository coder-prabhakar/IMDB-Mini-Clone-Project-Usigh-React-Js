function Print({pahle}) {
  return (
    <div style={{ fontSize:"40px" }}>
      <h1>{pahle}</h1>
    </div>
  )
}

export default Print
