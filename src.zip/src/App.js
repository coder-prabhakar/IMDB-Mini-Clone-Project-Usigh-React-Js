import { useState } from "react";
import SearchBar from "./SearchBar";
import Print from "./Print";

function App() {

  const [pahle,baad] = useState(["prabhakar kumar"]);

  function createItem(ans){
    let a = [...pahle];
    a[a.length] = ans;
    baad(a)
  }

  return (
    <div className="App">
      <SearchBar createItem={createItem}/>
      <Print pahle={pahle}/>
    </div>
  );
}

export default App;