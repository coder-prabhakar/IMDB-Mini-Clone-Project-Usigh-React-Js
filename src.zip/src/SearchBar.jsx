function SearchBar({createItem}) {

  var ans = "";
    function showWord(result) {
        ans = result.target.value
        
    }

    function dataSend(){
      createItem(ans)
    }
  
  return (
    <div>
      <input type="text" onChange={showWord}/>
      <button onClick={dataSend}>Click</button>
    </div>
  )
}

export default SearchBar
